<!DOCTYPE html>
<html lang="en">

<head>
 
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>

<body>
<?php
use App\Jobs;
if(1){
    $s=4;} 
?>
</body>

</html> <?php /**PATH C:\Projects\itjobseeker\resources\views/test.blade.php ENDPATH**/ ?>